// CppXML.cpp : Defines the entry point for the console application.
// ��ȡxml�浽txt

#include "stdafx.h"
#include <iostream>
#include <vector>
#include <fstream> 
#include <iostream>    
#include <string>
#include <cstdlib> 
#include <io.h>
#include "tinystr.h"
#include "tinyxml.h"

using namespace std;

//box�����ṹ��
struct BoxSize
{
	int xMin;
	int yMin;
	int xMax;
	int yMax;
};

bool ReadParaXml(string m_strXmlPath, vector<BoxSize>& vecNode, vector<int> &labels, string &picPath, int &imgW, int &imgH);
void printBoxAndLabel(vector<BoxSize> VBS, vector<int> LBS, string picPath);
vector<string> readClassNames(const char *filename);
int findLabelIdx(string str_label, vector<string> str_labels);
bool save2txt(string txt_path, vector<BoxSize> VBS, vector<int> LBS, int imgW, int imgH);
bool saveTrainTxt(string trainTxt, string PIC);
void getFileList(string path, vector<string> &fileList);

// read labels
vector<string> str_labels;

int main(int argc, char** argv)
{
	// 0����demo:��ȡ����xml; 1������ȡһ��Ŀ¼�µ�xml 
	string run_model = "";
	string readFold = "";
	string saveFold = "";
	string demoXml = "";
	string demoSave = "";
	string trainTxt = "";
	string labelTxt = "";
	

	if (argc!= 6) return -1;
	else {
		run_model = argv[1];
		if(run_model == "demo"){
			demoXml = argv[2];
			demoSave = argv[3];
			trainTxt = argv[4];
			labelTxt = argv[5];
		}
		else if(run_model == "folder") {
			readFold = argv[2];
			saveFold = argv[3];
			trainTxt = argv[4];
			labelTxt = argv[5];
		}
		else return -2;
	}

	// read str labels
	str_labels = readClassNames(labelTxt.c_str());

	if (run_model == "demo")
	{
		vector<BoxSize> vecNode;
		vector<int> labels;
		string picPath;
		int imgW,imgH;
		ReadParaXml(demoXml, vecNode, labels, picPath, imgW, imgH);
		//printBoxAndLabel(vecNode,labels, picPath);

		string txt_path = picPath.substr(0, picPath.rfind(".")) + ".txt";
		save2txt(txt_path, vecNode, labels, imgW, imgH);
	}
	else if (run_model == "folder") {
		vector<string> xmlList;
		getFileList(readFold, xmlList);

		// ����дtrain txt�ļ�
		ofstream outTrainTxt;
		outTrainTxt.open(trainTxt);

		for (int i = 0; i < xmlList.size(); i++) {
			cout << "current xml: " << xmlList[i] << endl;

			vector<BoxSize> vecNode;  // ���ο�
			vector<int> labels;       // ��ǩ
			string picPath;           // ͼ��·��
			int imgW, imgH;           // ͼ��ߴ�
			ReadParaXml(readFold+xmlList[i], vecNode, labels, picPath, imgW, imgH);  // ��ȡxml��ȡ������Ϣ

			string txt_path = saveFold + xmlList[i].substr(0, xmlList[i].rfind(".")) + ".txt"; // Txt·��

			//cout << txt_path << endl;

			save2txt(txt_path, vecNode, labels, imgW, imgH);                  // �洢
			outTrainTxt << picPath << endl;                                   // ����·����traintxt
		}
		outTrainTxt.close();
	}
	else return -3;

	system("pause");
    return 0;
}

bool saveTrainTxt(string trainTxt, string PIC)
{
	ofstream outf;
	outf.open(trainTxt);

	outf << PIC << endl;

	outf.close();
	return true;
}

// ����Ŀ¼
void getFileList(string path, vector<string> &fileList)
{
	intptr_t hFile = 0;
	struct _finddata_t fileInfo;
	string pathName;
	if ((hFile = _findfirst(pathName.assign(path).append("*.xml").c_str(), &fileInfo)) == -1) { return; }
	do {
		//fileList.push_back(path + "\\" + fileInfo.name);
		fileList.push_back(fileInfo.name);
	} while (_findnext(hFile, &fileInfo) == 0);
	_findclose(hFile);
	return;
}

bool save2txt(string txt_path, vector<BoxSize> VBS, vector<int> LBS, int imgW, int imgH)
{
	ofstream outf;
	outf.open(txt_path);
	
	if (VBS.size() != LBS.size()) return false;

	for (int i = 0; i < VBS.size(); i++)
	{
		outf << LBS[i] << " ";
		outf << (VBS[i].xMax + VBS[i].xMin) / (2.0*imgW) << " "; // X_center
		outf << (VBS[i].yMax + VBS[i].yMin) / (2.0*imgH) << " "; // Y_center
		outf << (VBS[i].xMax - VBS[i].xMin) / (1.0*imgW) << " "; // W
		outf << (VBS[i].yMax - VBS[i].yMin) / (1.0*imgH) <<endl; // H
		// δ�����
	}

	outf.close();
	return true;
}

void printBoxAndLabel(vector<BoxSize> VBS, vector<int> LBS,string picPath)
{
	cout << "pic: " << picPath << endl;
	cout << "----- vector BoxSize -----" << endl;
	for (int i = 0; i < VBS.size(); i++)
	{
		cout << "----- " << i << " -----" << endl;
		cout << "label: " << LBS[i] << endl;
		cout << "xMin: " << VBS[i].xMin << endl;
		cout << "xMax: " << VBS[i].xMax << endl;
		cout << "yMin: " << VBS[i].yMin << endl;
		cout << "yMax: " << VBS[i].yMax << endl;
	}
	cout << "----- vector BoxSize -----" << endl;
}

vector<string> readClassNames(const char *filename)
{
	vector<string> classNames;

	ifstream fp(filename);
	if (!fp.is_open())
	{
		cerr << "File with classes labels not found: " << filename << endl;
		exit(-1);
	}

	string name;
	while (!fp.eof())
	{
		getline(fp, name);
		if (name.length())
			classNames.push_back(name.substr(name.find(' ') + 1));
	}

	fp.close();
	return classNames;
}

int findLabelIdx(string str_label, vector<string> str_labels)
{
	int label = -1;
	for (int i = 0; i < str_labels.size(); i++)
		if (str_labels[i] == str_label) label = i;
	return label;
}

bool ReadParaXml(string m_strXmlPath, vector<BoxSize>& vecNode, vector<int> &labels, string &picPath,int &imgW, int &imgH)
{
	BoxSize *pNode = new BoxSize;

	//��ȡxml�ļ��еĲ���ֵ
	TiXmlDocument* Document = new TiXmlDocument();
	if (!Document->LoadFile(m_strXmlPath.c_str()))
	{
		cout << "�޷�����xml�ļ���" << endl;
		cin.get();
		return false;
	}
	TiXmlElement* RootElement = Document->RootElement();		//��Ŀ¼

	TiXmlElement* NextElement = RootElement->FirstChildElement();		//��Ŀ¼�µĵ�һ���ڵ��
																		//for(NextElement;NextElement;NextElement = NextElement->NextSiblingElement())
	while (NextElement != NULL)		//�ж���û�ж���
	{
		//ͼ���С��Ϣ
		if (NextElement->ValueTStr() == "size")         // ����path�ڵ�
		{
			TiXmlElement* widthElemeng = NextElement->FirstChildElement();
			TiXmlElement* heightElemeng = widthElemeng->NextSiblingElement();
			//cout << "width: " << widthElemeng->GetText() << endl;
			//cout << "height: " << heightElemeng->GetText() << endl;

			imgW = atoi(widthElemeng->GetText());
			imgH = atoi(heightElemeng->GetText());

			//string tmp_path = pathElemeng->GetText();
			//string::size_type pos = 0;
			//while ((pos = tmp_path.find('\\', pos)) != string::npos)
			//{
			//	tmp_path.insert(pos, "\\");//����  
			//	pos = pos + 2;
			//}
			//picPath = tmp_path;
		}

		// ͼ��·����Ϣ
		if (NextElement->ValueTStr() == "path")         // ����path�ڵ�
		{
			TiXmlElement* pathElemeng = NextElement;
			//cout << "path: " << pathElemeng->GetText() << endl;

			string tmp_path = pathElemeng->GetText();
			picPath = tmp_path;

			// �滻б��
			//string::size_type pos = 0;
	  //      while ((pos = tmp_path.find('\\', pos)) != string::npos)
	  //      {
			//	tmp_path.insert(pos, "\\");//����  
			//	pos = pos + 2;
			//}
			
		}

		// ͼ���ע��Ϣ
		if (NextElement->ValueTStr() == "object")		// ����object�ڵ�
		{
			//-----------------------------------------------------------
			TiXmlElement* labelElement = NextElement->FirstChildElement();
			while (labelElement->ValueTStr() != "name")	// ����box�ڵ�
			{
				labelElement = labelElement->NextSiblingElement();
			}

			TiXmlElement* labelnameElemeng = labelElement;
			string str_label = labelnameElemeng->GetText();
			int label = findLabelIdx(str_label, str_labels);
			labels.push_back(label);
			//-----------------------------------------------------------


			//NextElement = NextElement->NextSiblingElement();

			TiXmlElement* BoxElement = NextElement->FirstChildElement();
			while (BoxElement->ValueTStr() != "bndbox")		//����box�ڵ�
			{
				BoxElement = BoxElement->NextSiblingElement();
			}
			//������xmin�ڵ�
			TiXmlElement* xminElemeng = BoxElement->FirstChildElement();
			{
				//�ֱ��ȡ�ĸ���ֵ
				pNode->xMin = atof(xminElemeng->GetText());
				TiXmlElement* yminElemeng = xminElemeng->NextSiblingElement();
				pNode->yMin = atof(yminElemeng->GetText());
				TiXmlElement* xmaxElemeng = yminElemeng->NextSiblingElement();
				pNode->xMax = atof(xmaxElemeng->GetText());
				TiXmlElement* ymaxElemeng = xmaxElemeng->NextSiblingElement();
				pNode->yMax = atof(ymaxElemeng->GetText());

				//���뵽������
				vecNode.push_back(*pNode);
			}
		}
		NextElement = NextElement->NextSiblingElement();
	}

	//�ͷ��ڴ�
	delete pNode;
	delete Document;
	//cout << "���xml�Ķ�ȡ" << endl;
	return true;
}
